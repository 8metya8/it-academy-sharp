﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Player
{
    public class Song
    {
        public string Title { get; }
        public string TextOfSong { get; }

        public Song(string title, string text)
        {
            Title = title;
            TextOfSong = text;
        }
    }
}
